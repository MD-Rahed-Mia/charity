import React from 'react'

export default function AchiveCard() {
  return (
    <div>
      
    </div>
  )
}
