import React from 'react'

export default function LayoutPage() {
  return (
    <div>
      
    </div>
  )
}
